const grid=document.getElementById("grid"),cats=document.getElementById("cats"),search=document.getElementById("search"),count=document.getElementById("count");
let current="الكل";
function esc(s=""){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
async function load(){
 const qs=new URLSearchParams(); if(search.value.trim())qs.set("q",search.value.trim()); if(current!=="الكل")qs.set("category",current);
 const r=await fetch("/api/apps?"+qs); const apps=await r.json(); count.textContent=`${apps.length} تطبيق`;
 grid.innerHTML=apps.length?apps.map(a=>`<article class="card"><div class="icon">${a.icon?`<img src="/uploads/${esc(a.icon)}" alt="">`:`<div class="letter">آل</div>`}</div><h3>${esc(a.name)}</h3><div class="meta">${esc(a.category)} • الإصدار ${esc(a.version)}</div><p class="desc">${esc(a.description)}</p>${a.apk?`<a class="btn" href="/uploads/${esc(a.apk)}" download>تنزيل التطبيق</a>`:`<div class="btn soon">قريباً</div>`}</article>`).join(""):`<div class="empty">لا توجد نتائج حالياً.</div>`;
}
async function categories(){const r=await fetch("/api/apps");const apps=await r.json();const cs=["الكل",...new Set(apps.map(x=>x.category).filter(Boolean))];cats.innerHTML=cs.map(c=>`<button class="cat ${c===current?"active":""}" onclick="setCat('${esc(c)}')">${esc(c)}</button>`).join("")}
function setCat(c){current=c;categories();load()}
search.addEventListener("input",load); document.getElementById("year").textContent=new Date().getFullYear(); categories(); load();
