const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "CHANGE_THIS_TOKEN";

const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

const db = new Database(path.join(dataDir, "store.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS apps (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 description TEXT DEFAULT '',
 category TEXT DEFAULT 'أخرى',
 version TEXT DEFAULT '1.0.0',
 size TEXT DEFAULT '',
 rating REAL DEFAULT 0,
 icon TEXT DEFAULT '',
 apk TEXT DEFAULT '',
 featured INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
)`);

const count = db.prepare("SELECT COUNT(*) AS c FROM apps").get().c;
if (!count) {
  db.prepare(`INSERT INTO apps (name,description,category,version,size,rating,icon,apk,featured)
  VALUES (?,?,?,?,?,?,?,?,?)`).run(
    "متجر آل قيرمان",
    "منصة عربية فخمة لاكتشاف التطبيقات والملفات الرقمية.",
    "أدوات", "1.0.0", "قريباً", 5, "", "", 1
  );
}

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true, limit:"1mb"}));
app.use("/uploads", express.static(uploadDir, {maxAge:"1h"}));
app.use(express.static(path.join(__dirname, "public")));

app.use((req,res,next)=>{
  res.setHeader("X-Content-Type-Options","nosniff");
  res.setHeader("X-Frame-Options","SAMEORIGIN");
  res.setHeader("Referrer-Policy","strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy","camera=(), microphone=(), geolocation=()");
  next();
});

const storage = multer.diskStorage({
  destination: (_,__,cb)=>cb(null, uploadDir),
  filename: (_,file,cb)=>{
    const safe = Date.now()+"-"+file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_");
    cb(null,safe);
  }
});
const upload = multer({
  storage,
  limits:{fileSize:250*1024*1024},
  fileFilter:(_,file,cb)=>{
    const ok = /\.(apk|aab|png|jpg|jpeg|webp)$/i.test(file.originalname);
    cb(ok ? null : new Error("نوع الملف غير مسموح"), ok);
  }
});

function admin(req,res,next){
  const token = req.get("x-admin-token") || req.query.token || "";
  if(token !== ADMIN_TOKEN) return res.status(401).json({error:"غير مصرح"});
  next();
}

app.get("/api/apps",(req,res)=>{
  const q = String(req.query.q||"").trim();
  const category = String(req.query.category||"").trim();
  let sql="SELECT * FROM apps";
  const where=[], params=[];
  if(q){where.push("(name LIKE ? OR description LIKE ?)"); params.push("%"+q+"%","%"+q+"%");}
  if(category && category!=="الكل"){where.push("category=?");params.push(category);}
  if(where.length) sql+=" WHERE "+where.join(" AND ");
  sql+=" ORDER BY featured DESC, id DESC";
  res.json(db.prepare(sql).all(...params));
});

app.get("/api/apps/:id",(req,res)=>{
  const item=db.prepare("SELECT * FROM apps WHERE id=?").get(req.params.id);
  if(!item) return res.status(404).json({error:"غير موجود"});
  res.json(item);
});

app.post("/api/apps", admin, upload.fields([{name:"icon",maxCount:1},{name:"apk",maxCount:1}]), (req,res)=>{
  const b=req.body;
  if(!b.name) return res.status(400).json({error:"اسم التطبيق مطلوب"});
  const icon=req.files?.icon?.[0]?.filename||"";
  const apk=req.files?.apk?.[0]?.filename||"";
  const info=db.prepare(`INSERT INTO apps
  (name,description,category,version,size,rating,icon,apk,featured)
  VALUES (?,?,?,?,?,?,?,?,?)`).run(
    b.name,b.description||"",b.category||"أخرى",b.version||"1.0.0",
    b.size||"",Number(b.rating||0),icon,apk,Number(b.featured||0)
  );
  res.json({ok:true,id:info.lastInsertRowid});
});

app.delete("/api/apps/:id", admin, (req,res)=>{
  const item=db.prepare("SELECT icon,apk FROM apps WHERE id=?").get(req.params.id);
  if(!item) return res.status(404).json({error:"غير موجود"});
  for(const f of [item.icon,item.apk]) if(f) { try{fs.unlinkSync(path.join(uploadDir,f));}catch{} }
  db.prepare("DELETE FROM apps WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.get("/admin",(_,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));

app.listen(PORT,()=>console.log(`Al Qirman Store running on port ${PORT}`));
